<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

\Sitewell\StaticFrontend\Plugin::instance()->render();
