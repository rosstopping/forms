<?php
/**
 * Plugin Name: Sitewell Static Frontend
 * Description: Safely serves an approved static frontend while retaining WordPress administration.
 * Version: 0.1.0
 * Requires at least: 6.6
 * Requires PHP: 8.2
 * Author: Digizu
 * Text Domain: sitewell-static-frontend
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SITEWELL_STATIC_FRONTEND_VERSION', '0.1.0' );
define( 'SITEWELL_STATIC_FRONTEND_FILE', __FILE__ );
define( 'SITEWELL_STATIC_FRONTEND_PATH', plugin_dir_path( __FILE__ ) );

require_once SITEWELL_STATIC_FRONTEND_PATH . 'src/Contracts/StaticRootProvider.php';
require_once SITEWELL_STATIC_FRONTEND_PATH . 'src/BundledStaticRootProvider.php';
require_once SITEWELL_STATIC_FRONTEND_PATH . 'src/ResolvedStaticFile.php';
require_once SITEWELL_STATIC_FRONTEND_PATH . 'src/StaticPathResolver.php';
require_once SITEWELL_STATIC_FRONTEND_PATH . 'src/BypassPolicy.php';
require_once SITEWELL_STATIC_FRONTEND_PATH . 'src/FrontendRouter.php';
require_once SITEWELL_STATIC_FRONTEND_PATH . 'src/Admin/SettingsPage.php';
require_once SITEWELL_STATIC_FRONTEND_PATH . 'src/Plugin.php';

register_activation_hook( __FILE__, [ \Sitewell\StaticFrontend\Plugin::class, 'activate' ] );

\Sitewell\StaticFrontend\Plugin::instance()->boot();
