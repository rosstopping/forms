<?php

declare(strict_types=1);

namespace Sitewell\StaticFrontend\Admin;

use Sitewell\StaticFrontend\Contracts\StaticRootProvider;

final class SettingsPage {

	public const OPTION_ENABLED = 'sitewell_static_frontend_enabled';

	public function __construct( private readonly StaticRootProvider $staticRoot ) {
	}

	public function register(): void {
		add_options_page(
			__( 'Sitewell Static Frontend', 'sitewell-static-frontend' ),
			__( 'Sitewell Static Frontend', 'sitewell-static-frontend' ),
			'manage_options',
			'sitewell-static-frontend',
			[ $this, 'render' ],
		);
	}

	public function registerSettings(): void {
		register_setting(
			'sitewell_static_frontend',
			self::OPTION_ENABLED,
			[
				'type'              => 'boolean',
				'default'           => false,
				'sanitize_callback' => static fn ( mixed $value ): bool => $value === '1' || $value === 1 || $value === true,
			]
		);
	}

	public function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to manage this setting.', 'sitewell-static-frontend' ) );
		}

		$enabled   = self::isEnabled();
		$root      = realpath( $this->staticRoot->path() );
		$available = $root !== false && is_dir( $root ) && is_readable( $root ) && is_readable( $root . '/index.html' );
		?>
		<div class="wrap">
			<h1><?php echo esc_html__( 'Sitewell Static Frontend', 'sitewell-static-frontend' ); ?></h1>
			<p><?php echo esc_html__( 'This proof of concept can replace the public theme with the bundled static site. WordPress administration remains available.', 'sitewell-static-frontend' ); ?></p>

			<p>
				<strong><?php echo esc_html__( 'Status:', 'sitewell-static-frontend' ); ?></strong>
				<?php
				echo esc_html(
					! $available
						? __( 'Unavailable — the static fixture is missing or unreadable.', 'sitewell-static-frontend' )
						: ( $enabled ? __( 'Enabled', 'sitewell-static-frontend' ) : __( 'Disabled', 'sitewell-static-frontend' ) ),
				);
				?>
			</p>

			<p><strong><?php echo esc_html__( 'Static fixture:', 'sitewell-static-frontend' ); ?></strong> <code><?php echo esc_html( false !== $root ? $root : $this->staticRoot->path() ); ?></code></p>

			<form method="post" action="options.php">
				<?php settings_fields( 'sitewell_static_frontend' ); ?>
				<label for="sitewell-static-frontend-enabled">
					<input
						id="sitewell-static-frontend-enabled"
						name="<?php echo esc_attr( self::OPTION_ENABLED ); ?>"
						type="checkbox"
						value="1"
						<?php checked( $enabled ); ?>
						<?php disabled( ! $available ); ?>
					>
					<?php echo esc_html__( 'Enable static frontend', 'sitewell-static-frontend' ); ?>
				</label>
				<p class="description"><?php echo esc_html__( 'Clear this checkbox and save to restore the original WordPress frontend immediately.', 'sitewell-static-frontend' ); ?></p>
				<?php submit_button( $enabled ? __( 'Save or disable static frontend', 'sitewell-static-frontend' ) : __( 'Save and enable static frontend', 'sitewell-static-frontend' ) ); ?>
			</form>

			<p><a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'View public homepage', 'sitewell-static-frontend' ); ?></a></p>
		</div>
		<?php
	}

	public static function isEnabled(): bool {
		return (bool) get_option( self::OPTION_ENABLED, false );
	}
}
