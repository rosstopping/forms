<?php

declare(strict_types=1);

require_once dirname(__DIR__).'/src/Contracts/StaticRootProvider.php';
require_once dirname(__DIR__).'/src/ResolvedStaticFile.php';
require_once dirname(__DIR__).'/src/StaticPathResolver.php';
require_once dirname(__DIR__).'/src/BypassPolicy.php';
